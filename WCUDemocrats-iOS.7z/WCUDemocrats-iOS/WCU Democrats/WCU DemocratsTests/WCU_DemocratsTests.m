//
//  WCU_DemocratsTests.m
//  WCU DemocratsTests
//
//  Created by Chris Ward on 6/25/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "WCU_DemocratsTests.h"

@implementation WCU_DemocratsTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in WCU DemocratsTests");
}

@end
