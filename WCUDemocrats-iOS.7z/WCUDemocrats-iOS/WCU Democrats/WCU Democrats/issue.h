//
//  issue.h
//  WCU Democrats
//
//  Created by Chris Ward on 6/27/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface issue : NSObject
{
    NSString    *name;
    NSString    *body;
    NSString    *issue_id;
}

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *body;
@property (nonatomic, retain) NSString *issue_id;

@end
