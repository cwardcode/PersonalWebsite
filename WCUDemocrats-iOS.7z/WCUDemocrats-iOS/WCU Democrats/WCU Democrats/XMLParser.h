//
//  XMLParser.h
//  WCU Democrats
//
//  Created by Chris Ward on 6/27/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "issue.h"

@interface XMLParser : NSObject <NSXMLParserDelegate>
{
    NSMutableString *currentNode;
    NSMutableArray  *issues;
    NSXMLParser     *parser;
    issue           *curIssue;
    bool            isIssue;
}

@property (readonly, retain) NSMutableArray *issues;
-(id)   loadXMLByURL:(NSString *)url;
@end
