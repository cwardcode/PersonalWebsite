//
//  issue.m
//  WCU Democrats
//
//  Created by Chris Ward on 6/27/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "issue.h"

@implementation issue
@synthesize name, body,issue_id;

@end
