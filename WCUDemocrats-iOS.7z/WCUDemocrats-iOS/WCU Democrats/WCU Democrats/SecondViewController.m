//
//  SecondViewController.m
//  WCU Democrats
//
//  Created by Chris Ward on 6/25/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "SecondViewController.h"
#import "XMLParser.h"

@implementation SecondViewController
@synthesize curIssView;

NSMutableDictionary *selectedIndexes;
XMLParser *parser;
CGRect  nameFrame;
UILabel *nameLabel;
CGRect  bodyFrame;
UILabel *bodyLabel;
@interface SecondViewController (private)
-(bool) cellIsSelected:(NSIndexPath *)indexPath;
@end
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}
#pragma mark PopTableView
- (NSInteger) numberOfSectionsInTableView:(UITableView *) tableView
{
    return 1;
}

- (NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[parser issues] count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
    
    static NSString *cellID = @"Cell";
    issue *curIssue = [[parser issues] objectAtIndex:indexPath.row];
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
            
        
        CGRect nameFrame = CGRectMake(0,2,300,15);
        UILabel *nameLabel = [[UILabel alloc] initWithFrame:nameFrame];
        nameLabel.tag = 1;
        nameLabel.font = [UIFont boldSystemFontOfSize:12];
        [cell.contentView addSubview:nameLabel];
        
         CGRect bodyFrame = CGRectMake(0,16,300,60);
         UILabel *bodyLabel = [[UILabel alloc] initWithFrame:bodyFrame];
         bodyLabel.tag = 2;
         bodyLabel.numberOfLines = 10;
         bodyLabel.font = [UIFont systemFontOfSize:10];
        bodyLabel.hidden = YES;
         
         [cell.contentView addSubview:bodyLabel];
         
    }
    
    
    UILabel *nameLabel = (UILabel *)[cell.contentView viewWithTag:1];
    nameLabel.text     = [curIssue name];
    
    UILabel *bodyLabel = (UILabel *)[cell.contentView viewWithTag:2];
    bodyLabel.text     = [curIssue body];
    [curIssView beginUpdates];
    [curIssView endUpdates];

    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger defCellHeight  = 15;
    NSInteger heightModifier = 10;
    if([self cellIsSelected:indexPath]){
        
        return defCellHeight * heightModifier;
    }
    
    return defCellHeight;
}

-(bool) cellIsSelected:(NSIndexPath *)indexPath
{
    NSNumber *selIndex = [selectedIndexes objectForKey:indexPath];
    return selIndex == nil ? FALSE : [selIndex boolValue];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    BOOL isSeld = ![self cellIsSelected:indexPath];
    
    NSNumber *seldIndex = [NSNumber numberWithBool:isSeld];
    [selectedIndexes setObject:seldIndex forKey:indexPath];
    
    bodyLabel.hidden = NO;	
    [curIssView beginUpdates];
    [curIssView endUpdates];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    selectedIndexes = [[NSMutableDictionary alloc] init];
    parser = [[XMLParser alloc] loadXMLByURL:@"http://cwardcode.com/access/issues.xml"];
    self.title=@"Current Issues";
}

- (void)viewDidUnload
{
    [self setCurIssView:nil];
    [super viewDidUnload];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
}

- (void)viewDidDisappear:(BOOL)animated
{
	[super viewDidDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
