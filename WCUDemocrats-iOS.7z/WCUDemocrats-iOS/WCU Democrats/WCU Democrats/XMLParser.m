//
//  XMLParser.m
//  WCU Democrats
//
//  Created by Chris Ward on 6/27/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "XMLParser.h"
#import "issue.h"
	
@implementation XMLParser
@synthesize issues = issues;
 
-(id) loadXMLByURL:(NSString *)url
{
    issues  = [[NSMutableArray alloc]   init];
    NSURL   *xmlURL = [NSURL URLWithString:url];
    NSData  *data   = [[NSData alloc] initWithContentsOfURL:xmlURL];
    parser          =[[NSXMLParser alloc] initWithData:data];
    parser.delegate = self;
    [parser parse];
    return self;
}

- (void) parser:(NSXMLParser *)parser foundCharacters:(NSString *)string
{
    currentNode = (NSMutableString *) [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (void) parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    if ([elementName isEqualToString:@"issue"]) {
        curIssue = [issue alloc];
        isIssue  = true;
    }
    
}

-(void) parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if(isIssue) {
        if([elementName isEqualToString:@"issue_id"]) 
        {
            curIssue.issue_id = currentNode;
        }
        if([elementName isEqualToString:@"issue_name"]) 
        {
            curIssue.name = currentNode;
        }
        if([elementName isEqualToString:@"issue_body"]) 
        {
            curIssue.body = currentNode;
        }
    }
    if ([elementName isEqualToString:@"issue"]) {
        [self.issues addObject:curIssue];
        curIssue = nil;
        currentNode = nil;
    }
}
@end
